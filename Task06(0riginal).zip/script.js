   var set;
      var finalPos=0;
      var movecount=0,pausecount=0,resetcount=0,right=0,left,Top,bottom;
      var position = finalPos;
     function move(){
        if(movecount==0){
        movecount=1;
        pausecount=0;
        resetcount=0;
        var d = document.getElementById("moveMe");
      
        set = setInterval(function(){
             if(right==0){
               position+=5;
               d.style.left=position+"px";
               if(position>=230){ 
                  right=1;
               }
               finalPos=position;
             }
             else if(right==1){
                position-=5;
                d.style.left=position+"px";
                if(position<=0){
                  bottom=0;
                   right=2;
                }
                finalPos=position;
             }
             else if(bottom==0){
               position+=5;
                d.style.top=position+"px";
                if(position>=230){
                  bottom=1;
                }
                finalPos=position;
             }
             else if(bottom==1){
               position-=5;
                d.style.top=position+"px";
                if(position<=0){
                  bottom=2;
                  left=0;
                }
                finalPos=position;
             }
             else if(left==0){
               position-=5;
                d.style.left=position+"px";
                if(position<=-230){
                  left=1;
                }
                finalPos=position;
             }
             else if(left==1){
                position+=5;
                d.style.left=position+"px";
                if(position>=0){
                  left=2;
                  Top=0;
                }
                finalPos=position;
             }
             else{if(Top==0){
                position-=5;
                d.style.top=position+"px";
                if(position<=-230){
                  Top=1;
                }
                
                finalPos=position; 
             }
            else if(Top==1){
               position+=5;
                d.style.top=position+"px";
                if(position>=0){
                  right=0;
                }
                finalPos=position;
            }
            else {}}
             
            
        },10)
      }
 
     }
     
     function pause(){
        if(pausecount==0){
         clearInterval(set);
         movecount=0;
         pausecount=1;
         resetcount=0;
       }
     }

     function reset(){
      if(resetcount==0){
         var d = document.getElementById("moveMe");
         clearInterval(set);
         position=position-finalPos;
         d.style.top=position+"px";
         d.style.left=position+"px";
         movecount=0;
         right=0;
         pausecount=0;
         resetcount=1;
      }
     }