function myMove() {
  var container = document.getElementById("container");
  var elem = document.getElementById("animate");
  var id = setInterval(frame, 5);
  var maxDistToTravel = container.offsetWidth - elem.offsetWidth; 
  var pos = 0;
  var end = maxDistToTravel;
  var direction = 1;
  
  function frame() { 
   if (pos === end) {
     direction *= -1; 
     end = Math.abs(maxDistToTravel - end); 
   }
   pos += direction;
   elem.style.down = pos + "px";
   elem.style.left = pos + "px";
  }
}