window.addEventListener("load", () => {
  const { userAgent } = navigator;
  let bname = "";
  let bversion = "";
  if (userAgent.includes("Firefox/")) {
    bname = "Firefox";
    bversion = userAgent.match(/(?<=Firefox\/)\w+\b/);
  } else if (userAgent.includes("Edg/")) {
    bname = "Edge";
    bversion = userAgent.match(/(?<=Edg\/)\w+\b/);
  } else if (userAgent.includes("Chrome/")) {
    bname = "Chrome";
    bversion = userAgent.match(/(?<=Chrome\/)\w+\b/);
  } else if (userAgent.includes("Safari/")) {
    bname = "Safari";
    bversion = userAgent.match(/(?<=Safari\/)\w+\b/);
  }
  document.querySelector(".bname").innerHTML = bname;
  document.querySelector(".bversion").innerHTML = bversion;
  document.querySelector(".wid").innerHTML = window.innerWidth;
  document.querySelector(".hei").innerHTML = window.innerHeight;
});
window.addEventListener("resize", () => {
  document.querySelector(".wid").innerHTML = window.innerWidth;
  document.querySelector(".hei").innerHTML = window.innerHeight;
});