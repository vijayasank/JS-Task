function myMove() {
  var container = document.getElementById("container");
  var elem = document.getElementById("animate");
  var id = setInterval(frame, 5);
  var maxDistToTravel = container.offsetWidth - elem.offsetWidth; 
  var pos = 0;
  var end = maxDistToTravel;
  var direction = 2;
  
  function frame() { 
   if (pos === end) {
     direction *= -1; 
     end = Math.abs(maxDistToTravel - end); 
   }
   pos += direction;
   elem.style.down = pos + "px";
   elem.style.left = pos + "px";
  }
}
function myMove1() {
  var container = document.getElementById("container1");
  var elem = document.getElementById("animate1");
  var id = setInterval(frame1, 5);
  var maxDistToTravel = container.offsetHeight - elem.offsetHeight; 
  var pos = 0;
  var end = maxDistToTravel;
  var direction = 2;
  function frame1() { 
   if (pos === end) {
     direction *= -1; 
     end = Math.abs(maxDistToTravel - end); 
   }
   pos += direction;
   elem.style.down = pos + "px";
   elem.style.top = pos + "px";
  }
}
//--------------------------------------------

function myMove2() {
  var container = document.getElementById("container2");
  var elem = document.getElementById("animate2");
  var id = setInterval(frame2, 5);
  var maxDistToTravel = container.offsetHeight - elem.offsetHeight; 
  var pos = 0;
  var end = maxDistToTravel;
  var direction = 2;
  function frame2() { 
   if (pos === end) {
     direction *= -1; 
     end = Math.abs(maxDistToTravel - end); 
   }
   pos += direction;
   elem.style.top = pos + "px";
   elem.style.top = pos + "px";
  }
}
//--------------------------------------------

function myMove3() {
  var container = document.getElementById("container3");
  var elem = document.getElementById("animate3");
  var id = setInterval(frame3, 5);
  var maxDistToTravel = container.offsetHeight - elem.offsetHeight; 
  var pos = 0;
  var end = maxDistToTravel;
  var direction = 2;
  function frame3() { 
   if (pos === end) {
     direction *= -1; 
     end = Math.abs(maxDistToTravel - end); 
   }
   pos += direction;
   elem.style.down = pos + "px";
   elem.style.right = pos + "px";
  }
}